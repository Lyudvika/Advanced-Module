﻿namespace IteratorsAndComparators;

internal class Library
{

}