﻿namespace SplitMergeBinaryFile
{
    public class SplitMergeBinaryFile
    {
        static void Main()
        {
            string sourceFilePath = @"..\..\..\Files\example.png";
            string joinedFilePath = @"..\..\..\Files\example-joined.png";
            string partOnePath = @"..\..\..\Files\part-1.bin";
            string partTwoPath = @"..\..\..\Files\part-2.bin";

            SplitBinaryFile(sourceFilePath, partOnePath, partTwoPath);
            MergeBinaryFiles(partOnePath, partTwoPath, joinedFilePath);
        }

        public static void SplitBinaryFile(string sourceFilePath, string partOneFilePath, string partTwoFilePath)
        {
            using (StreamReader originalFile = new StreamReader(sourceFilePath))
            using (StreamWriter firstFile =  new StreamWriter(partOneFilePath))
            using (StreamWriter secondFile = new StreamWriter(partTwoFilePath))
            {
                byte[] buffer = originalFile
                    .ReadToEnd()
                    .Split()
                    .Select(byte.Parse)
                    .ToArray();

                for (int i = 0; i < buffer.Length / 2; i++)
                {
                    if (i % 2 == 0)
                    {
                        firstFile.Write(buffer[i]);
                    }
                    else
                    {
                        secondFile.Write(buffer[i]);
                    }
                }

                for (int i = 0 ; i < buffer.Length ; i++)
                {

                }
            }
        }

        public static void MergeBinaryFiles(string partOneFilePath, string partTwoFilePath, string joinedFilePath)
        {
            using (StreamWriter firstFile = new StreamWriter(partOneFilePath))
            using (StreamWriter secondFile = new StreamWriter(partTwoFilePath))
            using (StreamWriter mergedFile = new StreamWriter(joinedFilePath))
            {
                
            }
        }
    }
}