﻿namespace Zoo;
public class StartUp
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}