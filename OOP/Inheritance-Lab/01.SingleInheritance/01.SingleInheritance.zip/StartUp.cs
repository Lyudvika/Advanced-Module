﻿using Farm;
public class StartUp
{
    private static void Main(string[] args)
    {
        Dog dog = new();
        dog.Bark();
        dog.Bark();
        dog.Eat();
    }
}