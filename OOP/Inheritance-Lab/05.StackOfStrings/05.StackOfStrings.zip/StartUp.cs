﻿using CustomStack;
public class StartUp
{
    private static void Main(string[] args)
    {

    }
}