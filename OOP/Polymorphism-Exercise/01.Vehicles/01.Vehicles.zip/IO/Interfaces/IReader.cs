﻿namespace Vehicles.IO.Interfaces;   //DONE

public interface IReader
{
   string ReadLine();
}
