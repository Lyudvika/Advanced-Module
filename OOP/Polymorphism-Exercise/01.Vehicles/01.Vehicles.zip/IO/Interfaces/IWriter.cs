﻿namespace Vehicles.IO.Interfaces;   //DONE

public interface IWriter
{
    void WriteLine(string text);
}
